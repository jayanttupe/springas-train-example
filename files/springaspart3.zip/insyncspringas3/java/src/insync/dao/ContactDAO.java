package insync.dao;

import insync.model.Contact;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class ContactDAO {

	public List<Contact> getContacts() {
		System.out.println("ContactDAO: getContacts");
		List<Contact> list = new ArrayList<Contact>();
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery("SELECT * FROM contact ORDER BY last_name, first_name");
			while (rs.next()) {
				list.add(processRow(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return list;
	}

	public List<Contact> getContactsByName(String name) {
		System.out.println("ContactDAO: getContactsByName " + name);
		List<Contact> list = new ArrayList<Contact>();
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			PreparedStatement ps = c.prepareStatement("SELECT * FROM contact WHERE UPPER(first_name + ' ' + last_name) LIKE ? OR UPPER(last_name + ' ' + first_name) LIKE ? ORDER BY last_name, first_name");
			String likeStr = "%" + name.toUpperCase() + "%";
			ps.setString(1, likeStr);
			ps.setString(2, likeStr);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				list.add(processRow(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return list;
	}
	
	public Contact getContact(int id) {
		System.out.println("ContactDAO: getContact " + id);
		Contact contact = null;
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			PreparedStatement ps = c.prepareStatement("SELECT * FROM contact WHERE id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				contact = processRow(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return contact;
	}

	public Contact save(Contact contact)
	{
		return contact.getId() > 0 ? update(contact) : create(contact);
	}

	public Contact create(Contact contact) {
		System.out.println("ContactDAO: create contact " + contact.getId() + " " +contact.getFirstName() + " " + contact.getLastName());
		Connection c = null;
		PreparedStatement ps = null;
		try {
			c = ConnectionHelper.getConnection();
			ps = c.prepareStatement("INSERT INTO contact (first_name, last_name, address, city, state, zip, phone, email, pic) VALUES (?,?,?,?,?,?,?,?,?)");
			ps.setString(1, contact.getFirstName());
			ps.setString(2, contact.getLastName());
			ps.setString(3, contact.getAddress());
			ps.setString(4, contact.getCity());
			ps.setString(5, contact.getState());
			ps.setString(6, contact.getZip());
			ps.setString(7, contact.getPhone());
			ps.setString(8, contact.getEmail());
			ps.setBytes(9, contact.getPic());
			ps.executeUpdate();
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery("CALL IDENTITY()");
			rs.next();
            // Update the id in the returned object. This is important as this value must get returned to the client.
			contact.setId(rs.getInt(1));
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return contact;
	}

	public Contact update(Contact contact) {
		System.out.println("ContactDAO: update contact " + contact.getId() + " " +contact.getFirstName() + " " + contact.getLastName());
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			PreparedStatement ps = c.prepareStatement("UPDATE contact SET first_name=?, last_name=?, address=?, city=?, state=?, zip=?, phone=?, email=?, pic=? WHERE id=?");
			ps.setString(1, contact.getFirstName());
			ps.setString(2, contact.getLastName());
			ps.setString(3, contact.getAddress());
			ps.setString(4, contact.getCity());
			ps.setString(5, contact.getState());
			ps.setString(6, contact.getZip());
			ps.setString(7, contact.getPhone());
			ps.setString(8, contact.getEmail());
			ps.setBytes(9, contact.getPic());
			ps.setInt(10, contact.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return contact;
	}

	public Contact updatePicture(Contact contact) {
		System.out.println("ContactDAO: update picture " + contact.getId() + " " +contact.getFirstName() + " " + contact.getLastName());
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			PreparedStatement ps = c.prepareStatement("UPDATE contact SET pic=? WHERE id=?");
			ps.setBytes(1, contact.getPic());
			ps.setInt(2, contact.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
		return contact;
	}

	public boolean remove(Contact contact) {
		System.out.println("ContactDAO: remove contact " + contact.getId() + " " +contact.getFirstName() + " " + contact.getLastName());
		Connection c = null;
		try {
			c = ConnectionHelper.getConnection();
			PreparedStatement ps = c.prepareStatement("DELETE FROM contact WHERE id=?");
			ps.setInt(1, contact.getId());
			int count = ps.executeUpdate();
			return (count == 1);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ConnectionHelper.close(c);
		}
	}
	
	protected Contact processRow(ResultSet rs) throws SQLException
	{
		Contact contact = new Contact();
		contact.setId(rs.getInt("id"));
		contact.setFirstName(rs.getString("first_name"));
		contact.setLastName(rs.getString("last_name"));
		contact.setPhone(rs.getString("phone"));
		contact.setEmail(rs.getString("email"));
		contact.setAddress(rs.getString("address"));
		contact.setCity(rs.getString("city"));
		contact.setState(rs.getString("state"));
		contact.setZip(rs.getString("zip"));
		contact.setPic(rs.getBytes("pic"));
		return contact;
	}
	
}