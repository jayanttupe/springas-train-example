package insync.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHelper {

    private String url;
    private static ConnectionHelper instance;

    private ConnectionHelper() {
    	String driver = null;
        try {
            Class.forName("org.hsqldb.jdbcDriver");
            url="jdbc:hsqldb:hsql://localhost:9002/insync";
        } catch (ClassNotFoundException e) {
			System.out.println("ERROR: Error loading JDBC driver. Class " + driver + "not found.");
        }
    }

	public static Connection getConnection() throws SQLException {
		if (instance == null) {
			instance = new ConnectionHelper();
		}
		try {
			return DriverManager.getConnection(instance.url);
		} catch (SQLException e) {
			String msg =  " -- Make sure that you successfully started the database.";
			System.out.println("ERROR: " + e.getMessage() + msg);
			throw new SQLException(e.getMessage() + msg);
		}
	}

	public static void close(Connection connection) {
        try {
        	if (connection != null) {
        		connection.close();
        	}
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

}